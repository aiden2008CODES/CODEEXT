#### Mod Version:
---
```
[ insert version ]
```
#### Crash log (if applicable):
---
```
[ paste.ee link or other paste service link ]
```
#### Issue Details:
---
```
[ please explain the issue in details. One line does not give a lot of information to work with ]
```
#### Notes:
---
```
[ Add any extra information you think might be useful ]
```
#### Images (optional):
---

[ Add images if you think it will be useful to resolving the issue ]
