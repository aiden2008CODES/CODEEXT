[![](https://img.shields.io/badge/Discord-MMD-green.svg?style=flat&logo=Discord)](https://discord.mcmoddev.com)
[![](http://cf.way2muchnoise.eu/full_more-organized-player-menus_downloads.svg)](http://minecraft.curseforge.com/projects/more-organized-player-menus)
[![](http://cf.way2muchnoise.eu/versions/Minecraft_more-organized-player-menus_all.svg)](http://minecraft.curseforge.com/projects/more-organized-player-menus)
[![Build Status](https://ci.mcmoddev.com/job/MOPM/badge/icon)](https://ci.mcmoddev.com/job/MOPM/)

# More Organised Player Menus
