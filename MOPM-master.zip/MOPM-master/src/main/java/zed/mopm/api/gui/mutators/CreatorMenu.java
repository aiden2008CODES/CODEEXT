package zed.mopm.api.gui.mutators;

public class CreatorMenu {
    private CreatorMenu() { }

    public static final int CREATION_ID = 0;
    public static final int TOGGLE_DISPLAY_ID = 3;
}
