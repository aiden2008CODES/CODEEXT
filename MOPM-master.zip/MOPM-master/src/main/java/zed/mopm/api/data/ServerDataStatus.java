package zed.mopm.api.data;

public enum ServerDataStatus {
    ADDING,
    EDITING,
    REMOVING,
    DIRECT_CONNECTING,
    NONE
}
