package zed.mopm.api.gui;

public enum SelectedList {
    ENTRY_LIST,
    DIRECTORY_LIST,
    BUTTONS
}
