package zed.mopm.api.data;

public interface IDrawableListEntry {
    int getX();
    int getY();
    String getEntryText();
}
