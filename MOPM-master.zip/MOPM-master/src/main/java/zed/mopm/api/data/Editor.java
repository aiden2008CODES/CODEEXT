package zed.mopm.api.data;

public enum Editor {
    RENAME,
    DELETE,
    CHANGE_DIRECTORY
}
